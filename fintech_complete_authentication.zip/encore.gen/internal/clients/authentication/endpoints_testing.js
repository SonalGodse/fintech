import { apiCall, streamIn, streamOut, streamInOut } from "encore.dev/internal/codegen/api";
import { registerTestHandler } from "encore.dev/internal/codegen/appinit";

import * as authentication_service from "../../../../services\\authentication\\encore.service";

export async function refreshToken(params) {
    const handler = (await import("../../../../services\\authentication\\api")).refreshToken;
    registerTestHandler({
        apiRoute: { service: "authentication", name: "refreshToken", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: authentication_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("authentication", "refreshToken", params);
}

export async function login(params) {
    const handler = (await import("../../../../services\\authentication\\api")).login;
    registerTestHandler({
        apiRoute: { service: "authentication", name: "login", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: authentication_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("authentication", "login", params);
}

export async function saveMpin(params) {
    const handler = (await import("../../../../services\\authentication\\api")).saveMpin;
    registerTestHandler({
        apiRoute: { service: "authentication", name: "saveMpin", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: authentication_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("authentication", "saveMpin", params);
}

export async function createUserAndAccount(params) {
    const handler = (await import("../../../../services\\authentication\\api")).createUserAndAccount;
    registerTestHandler({
        apiRoute: { service: "authentication", name: "createUserAndAccount", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: authentication_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("authentication", "createUserAndAccount", params);
}

export async function forgotPassword(params) {
    const handler = (await import("../../../../services\\authentication\\api")).forgotPassword;
    registerTestHandler({
        apiRoute: { service: "authentication", name: "forgotPassword", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: authentication_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("authentication", "forgotPassword", params);
}

export async function resetPassword(params) {
    const handler = (await import("../../../../services\\authentication\\api")).resetPassword;
    registerTestHandler({
        apiRoute: { service: "authentication", name: "resetPassword", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: authentication_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("authentication", "resetPassword", params);
}

export async function getGuidDetail(params) {
    const handler = (await import("../../../../services\\authentication\\api")).getGuidDetail;
    registerTestHandler({
        apiRoute: { service: "authentication", name: "getGuidDetail", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: authentication_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("authentication", "getGuidDetail", params);
}

export async function verifyOtp(params) {
    const handler = (await import("../../../../services\\authentication\\api")).verifyOtp;
    registerTestHandler({
        apiRoute: { service: "authentication", name: "verifyOtp", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: authentication_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("authentication", "verifyOtp", params);
}

