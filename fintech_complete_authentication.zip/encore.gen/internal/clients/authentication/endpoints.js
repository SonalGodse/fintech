import { apiCall, streamIn, streamOut, streamInOut } from "encore.dev/internal/codegen/api";

const TEST_ENDPOINTS = typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test"
    ? await import("./endpoints_testing.js")
    : null;

export async function refreshToken(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.refreshToken(params);
    }

    return apiCall("authentication", "refreshToken", params);
}

export async function login(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.login(params);
    }

    return apiCall("authentication", "login", params);
}

export async function saveMpin(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.saveMpin(params);
    }

    return apiCall("authentication", "saveMpin", params);
}

export async function createUserAndAccount(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.createUserAndAccount(params);
    }

    return apiCall("authentication", "createUserAndAccount", params);
}

export async function forgotPassword(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.forgotPassword(params);
    }

    return apiCall("authentication", "forgotPassword", params);
}

export async function resetPassword(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.resetPassword(params);
    }

    return apiCall("authentication", "resetPassword", params);
}

export async function getGuidDetail(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getGuidDetail(params);
    }

    return apiCall("authentication", "getGuidDetail", params);
}

export async function verifyOtp(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.verifyOtp(params);
    }

    return apiCall("authentication", "verifyOtp", params);
}

