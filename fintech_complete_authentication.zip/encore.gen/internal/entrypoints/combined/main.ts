import { registerGateways, registerHandlers, run, type Handler } from "encore.dev/internal/codegen/appinit";

import { get as hello_getImpl0 } from "../../../../hello\\hello";
import { refreshToken as authentication_refreshTokenImpl1 } from "../../../../services\\authentication\\api";
import { login as authentication_loginImpl2 } from "../../../../services\\authentication\\api";
import { saveMpin as authentication_saveMpinImpl3 } from "../../../../services\\authentication\\api";
import { createUserAndAccount as authentication_createUserAndAccountImpl4 } from "../../../../services\\authentication\\api";
import { forgotPassword as authentication_forgotPasswordImpl5 } from "../../../../services\\authentication\\api";
import { resetPassword as authentication_resetPasswordImpl6 } from "../../../../services\\authentication\\api";
import { getGuidDetail as authentication_getGuidDetailImpl7 } from "../../../../services\\authentication\\api";
import { verifyOtp as authentication_verifyOtpImpl8 } from "../../../../services\\authentication\\api";
import * as hello_service from "../../../../hello\\encore.service";
import * as authentication_service from "../../../../services\\authentication\\encore.service";

const gateways: any[] = [
];

const handlers: Handler[] = [
    {
        apiRoute: {
            service:           "hello",
            name:              "get",
            handler:           hello_getImpl0,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: hello_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "refreshToken",
            handler:           authentication_refreshTokenImpl1,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "login",
            handler:           authentication_loginImpl2,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "saveMpin",
            handler:           authentication_saveMpinImpl3,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "createUserAndAccount",
            handler:           authentication_createUserAndAccountImpl4,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "forgotPassword",
            handler:           authentication_forgotPasswordImpl5,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "resetPassword",
            handler:           authentication_resetPasswordImpl6,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "getGuidDetail",
            handler:           authentication_getGuidDetailImpl7,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "verifyOtp",
            handler:           authentication_verifyOtpImpl8,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
];

registerGateways(gateways);
registerHandlers(handlers);

await run(import.meta.url);
