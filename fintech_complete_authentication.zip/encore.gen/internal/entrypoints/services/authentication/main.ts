import { registerHandlers, run, type Handler } from "encore.dev/internal/codegen/appinit";
import { Worker, isMainThread } from "node:worker_threads";
import { fileURLToPath } from "node:url";
import { availableParallelism } from "node:os";

import { refreshToken as refreshTokenImpl0 } from "../../../../../services\\authentication\\api";
import { login as loginImpl1 } from "../../../../../services\\authentication\\api";
import { saveMpin as saveMpinImpl2 } from "../../../../../services\\authentication\\api";
import { createUserAndAccount as createUserAndAccountImpl3 } from "../../../../../services\\authentication\\api";
import { forgotPassword as forgotPasswordImpl4 } from "../../../../../services\\authentication\\api";
import { resetPassword as resetPasswordImpl5 } from "../../../../../services\\authentication\\api";
import { getGuidDetail as getGuidDetailImpl6 } from "../../../../../services\\authentication\\api";
import { verifyOtp as verifyOtpImpl7 } from "../../../../../services\\authentication\\api";
import * as authentication_service from "../../../../../services\\authentication\\encore.service";

const handlers: Handler[] = [
    {
        apiRoute: {
            service:           "authentication",
            name:              "refreshToken",
            handler:           refreshTokenImpl0,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "login",
            handler:           loginImpl1,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "saveMpin",
            handler:           saveMpinImpl2,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "createUserAndAccount",
            handler:           createUserAndAccountImpl3,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "forgotPassword",
            handler:           forgotPasswordImpl4,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "resetPassword",
            handler:           resetPasswordImpl5,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "getGuidDetail",
            handler:           getGuidDetailImpl6,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "authentication",
            name:              "verifyOtp",
            handler:           verifyOtpImpl7,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: authentication_service.default.cfg.middlewares || [],
    },
];

registerHandlers(handlers);

await run(import.meta.url);
