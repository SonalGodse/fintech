export * as hello from "../internal/clients/hello/endpoints";
export * as authentication from "../internal/clients/authentication/endpoints";
