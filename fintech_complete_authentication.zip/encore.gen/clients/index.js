export * as hello from "../internal/clients/hello/endpoints.js";
export * as authentication from "../internal/clients/authentication/endpoints.js";
